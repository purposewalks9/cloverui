
import type { Metadata } from "next";
import { constructMetadata } from "@/lib/utils";
import Script from "next/script";
import {
  DynaPuff,
  Geist,
  Geist_Mono,
  Instrument_Serif,
} from "next/font/google";
import { Analytics } from "@vercel/analytics/next";
import { SpeedInsights } from "@vercel/speed-insights/next";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import { JotaiProvider } from "@/components/providers";
import AnimatedGradient from "@/components/animated-gradient";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const instrumentSerif = Instrument_Serif({
  variable: "--font-instrument-serif",
  subsets: ["latin"],
  weight: ["400"],
  preload: false,
});

const dynaPuff = DynaPuff({
  variable: "--font-dyna-puff",
  subsets: ["latin"],
  preload: false,
});

export const metadata: Metadata = constructMetadata({
  title: "Clover UI",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning data-scroll-behavior="smooth">
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${instrumentSerif.variable} ${dynaPuff.variable} relative isolate min-h-dvh overflow-x-hidden bg-[#050505] text-foreground antialiased font-sans`}
        suppressHydrationWarning
      >
        <JotaiProvider>
          <ThemeProvider
            attribute="class"
            defaultTheme="dark"
            forcedTheme="dark"
            enableSystem={false}
            disableTransitionOnChange
          >
            <AnimatedGradient
              config={{
                preset: "custom",
                color1: "#05060d",   // near-black void
                color2: "#1a1044",   // deep violet nebula
                color3: "#0a1a33",   // faint blue glow
                speed: 0,            // slow drift, not static
                rotation: -35,
                proportion: 38,
                scale: 0.35,
                distortion: 18,
                swirl: 45,
                swirlIterations: 14,
                softness: 100,
                offset: -300,
                shape: "Checks",
                shapeSize: 70,
              }}
              noise={{ opacity: 0.06, scale: 0.6 }}
              style={{
                position: "fixed",
                inset: 0,
                zIndex: 0,
                opacity: 1,
                pointerEvents: "none",
              }}
            />

            <div className="pointer-events-none fixed inset-0 z-[1] bg-[#050505]/35" />

            <div className="relative z-10 min-h-dvh">
              {children}
            </div>
          </ThemeProvider>
        </JotaiProvider>

        <SpeedInsights />
        <Analytics />
      </body>
    </html>
  );
}