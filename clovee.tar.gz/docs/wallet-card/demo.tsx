import { WalletCard } from "@/registry/clover-ui/wallet-card";

export function Demo() {
  return <WalletCard />;
}
