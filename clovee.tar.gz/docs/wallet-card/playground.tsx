"use client";

import { WalletCard } from "@/registry/clover-ui/wallet-card";
import { PlaygroundShell } from "@/components/playground/playground-shell";
import type { ControlDef } from "@/lib/playground";

const controls: ControlDef[] = [
  { type: "text", prop: "brand", label: "Brand" },
  { type: "text", prop: "cardNumber", label: "Card number" },
  { type: "text", prop: "cardHolder", label: "Card holder" },
  { type: "text", prop: "expiry", label: "Expiry" },
  { type: "text", prop: "limitLabel", label: "Limit label" },
  { type: "text", prop: "limitAmount", label: "Limit amount" },
  { type: "boolean", prop: "defaultOpen", label: "Start pulled out" },
];

const defaultProps = {
  brand: "Master Card",
  cardNumber: "3745 6987 4096 3960",
  cardHolder: "Alex Morgan",
  expiry: "09/29",
  limitLabel: "Limit Card",
  limitAmount: "$43,865.00",
  defaultOpen: false,
};

export function WalletCardPlayground() {
  return (
    <PlaygroundShell
      componentName="WalletCard"
      controls={controls}
      defaultProps={defaultProps}
      render={(values) => (
        <div className="flex w-full justify-center py-6">
          <WalletCard
            brand={values.brand as string}
            cardNumber={values.cardNumber as string}
            cardHolder={values.cardHolder as string}
            expiry={values.expiry as string}
            limitLabel={values.limitLabel as string}
            limitAmount={values.limitAmount as string}
            defaultOpen={values.defaultOpen as boolean}
          />
        </div>
      )}
    />
  );
}
